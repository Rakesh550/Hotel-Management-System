 <?php
//including the database connection file
require_once ('dbh.php');

//getting id of the data from url
$id = $_GET['id'];
//echo $id;


$start = $_POST['start'];
//echo "$reason";


$sql = "INSERT INTO `employee_attendence`(`id`,`token`, `start`,  `status`) VALUES ('$id','','$start','Pending')";

$result = mysqli_query($conn, $sql);

//redirecting to the display page (index.php in our case)
header("Location:..//eloginwel.php?id=$id");
?>


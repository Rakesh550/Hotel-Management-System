<?php

require_once ('process/dbh.php');
$sql = "SELECT employee.id,employee.firstName,employee.lastName,salary.base,salary.bonus,salary.total from employee,`salary` where employee.id=salary.id";

//echo "$sql";
$result = mysqli_query($conn, $sql);

?>



<html>
<head>
	<title>Salary Table | Employee Management System</title>
	<link rel="stylesheet" type="text/css" href="styleview.css">
</head>
<body>
	
	<header>
		<nav>
			<h1>EMS</h1>
			<ul id="navli">
				<li><a class="homeblack" href="aloginwel.php">HOME</a></li>
				
				<li><a class="homeblack" href="addemp.php">Add Employee</a></li>
				<li><a class="homeblack" href="viewemp.php">View Employee</a></li>
				<li><a class="homeblack" href="assign.php">Assign Project</a></li>
				<li><a class="homeblack" href="assignproject.php">Project Status</a></li>
				<li><a class="homered" href="salaryemp.php">Salary Table</a></li>
				<li><a class="homeblack" href="empleave.php">Employee Leave</a></li>
								<li><a class="homeblack" href="empattendence.php">Employee Attendence</a></li>

				<li><a class="homeblack" href="alogin.html">Log Out</a></li>
			</ul>
		</nav>
	</header>
	 
	<div class="divider"></div>
	<div id="divimg">
		
	</div>
	
	<table>
			<tr>
				<th align = "center">Emp. ID</th>
				<th align = "center">Name</th>
				
				
				<th align = "center">Base Salary</th>
				<th align = "center">Attendence</th>
				<th align = "center">Leave</th>
				
				<th align = "center">Bonus</th>
				<th align = "center">TotalSalary</th>
				
				
			</tr>
			
			<?php
				while ($employee = mysqli_fetch_assoc($result)) {
					$cid=$employee['id'];
					$sqlcid = "SELECT id from `employee_attendence`  WHERE employee_attendence.id=$cid";

//echo "$sql";
$resultcid = mysqli_query($conn, $sqlcid);
$cntatd=mysqli_num_rows($resultcid);



$sqlliv= "SELECT * from `employee_leave`  WHERE employee_leave.id=$cid";
$resultlivx = mysqli_query($conn, $sqlliv);
//echo "$sql";
$resultliv = mysqli_fetch_assoc($resultlivx);
$date1 = new DateTime($resultliv['start']);
				$date2 = new DateTime($resultliv['end']);
				$interval = $date1->diff($date2);
				$interval = $date1->diff($date2);
				
				$intt=26;
				$sal=$employee['base']/$intt;
				$totaldays=$cntatd-$interval->days;
				$totalsalry=$sal*$totaldays;
				
					echo "<tr>";
					echo "<td>".$employee['id']."</td>";
					echo "<td>".$employee['firstName']." ".$employee['lastName']."</td>";
					
					echo "<td>".$employee['base']."</td>";
					echo "<td>".$cntatd."</td>";
					echo "<td>".$interval->days."</td>";
					
					
					
					
					echo "<td>".$employee['bonus']." %</td>";
					echo "<td>".$totalsalry."</td>";
					
					

				}


			?>
			
			</table>
</body>
</html>
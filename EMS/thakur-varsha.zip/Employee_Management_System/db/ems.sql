-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `alogin`;
CREATE TABLE `alogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` tinytext NOT NULL,
  `password` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `alogin` (`id`, `email`, `password`) VALUES
(1,	'admin@gmail.com',	'admin');

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) NOT NULL,
  `lastName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `nid` int(20) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `dept` varchar(100) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `pic` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employee` (`id`, `firstName`, `lastName`, `email`, `password`, `birthday`, `gender`, `contact`, `nid`, `address`, `dept`, `degree`, `pic`) VALUES
(7,	'Testing X',	'Y',	'test@gmail.com',	'1234',	'1996-03-13',	'Male',	'9874563210',	1,	'xyz, vda',	'IT',	'B.Tech',	'images/Euclid.png'),
(8,	'Varsha',	'Thakur',	'varshathakur@gmail.com',	'1234',	'1999-03-11',	'Female',	'11111111111',	12,	'KTU',	'IT',	'Computer Applications',	'images/kaunas.png');

DROP TABLE IF EXISTS `employee_attendence`;
CREATE TABLE `employee_attendence` (
  `id` int(11) DEFAULT NULL,
  `token` int(11) NOT NULL,
  `start` date DEFAULT NULL,
  `status` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employee_attendence` (`id`, `token`, `start`, `status`) VALUES
(7,	0,	'2021-05-22',	'Approved'),
(7,	0,	'2021-05-24',	'Approved'),
(8,	0,	'2021-05-22',	'Approved'),
(8,	0,	'2021-05-24',	'Approved'),
(8,	0,	'2021-05-25',	'Approved'),
(8,	0,	'2021-05-26',	'Approved');

DROP TABLE IF EXISTS `employee_leave`;
CREATE TABLE `employee_leave` (
  `id` int(11) DEFAULT NULL,
  `token` int(11) NOT NULL AUTO_INCREMENT,
  `start` date DEFAULT NULL,
  `end` date DEFAULT NULL,
  `reason` char(100) DEFAULT NULL,
  `status` char(50) DEFAULT NULL,
  PRIMARY KEY (`token`),
  KEY `employee_leave_ibfk_1` (`id`),
  CONSTRAINT `employee_leave_ibfk_1` FOREIGN KEY (`id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `employee_leave` (`id`, `token`, `start`, `end`, `reason`, `status`) VALUES
(7,	4,	'2021-05-22',	'2021-05-23',	'hhhh',	'Approved'),
(8,	5,	'2021-05-22',	'2021-05-24',	'ffffffffg',	'Approved');

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `eid` int(11) DEFAULT NULL,
  `pname` varchar(100) DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `subdate` date DEFAULT '0000-00-00',
  `mark` int(11) NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `remark` text,
  PRIMARY KEY (`pid`),
  KEY `project_ibfk_1` (`eid`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `project` (`pid`, `eid`, `pname`, `duedate`, `subdate`, `mark`, `status`, `remark`) VALUES
(3,	7,	'xaaaaa',	'2021-05-22',	'2021-05-22',	56,	'Submitted',	'sgash');

DROP TABLE IF EXISTS `rank`;
CREATE TABLE `rank` (
  `eid` int(11) NOT NULL,
  `points` int(11) DEFAULT '0',
  PRIMARY KEY (`eid`),
  CONSTRAINT `rank_ibfk_1` FOREIGN KEY (`eid`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `rank` (`eid`, `points`) VALUES
(7,	100),
(8,	0);

DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `base` int(11) NOT NULL,
  `bonus` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`id`) REFERENCES `employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `salary` (`id`, `base`, `bonus`, `total`) VALUES
(7,	6000,	100,	200000),
(8,	1000000,	0,	1000000);

-- 2021-05-22 15:19:49

<?php

require_once ('process/dbh.php');
//$id = (isset($_GET['id']) ? $_GET['id'] : '');
$pid = $_POST['pid'];
$id = $_POST['id'];
$remark = $_POST['remark'];
$date = date('Y-m-d');
//echo "$date";
$sql = "UPDATE `project` SET `subdate`='$date',`status`='Submitted',`remark`='$remark' WHERE pid = '$pid';";
$result = mysqli_query($conn , $sql);
header("Location: empproject.php?id=$id");
?>